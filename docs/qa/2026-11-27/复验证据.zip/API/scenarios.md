# 服务端业务验证

基准提交 `25c4b52c`。已有测试 `cd server && npm test` 为 57/57，通过真实 workerd/Miniflare 与隔离 D1 做了 34 项额外业务检查，另有短信运行时和 Android 商城解码各 1 项，共 36 项，26 项通过、10 项出现偏差。主矩阵共 229 次 HTTP 调用。每个自建运行时均已 dispose，所有测试命令已退出。无线上请求或写操作，无产品修改。

## 复现记录

|优先级|现象与正常操作|实际与预期|定位|
|---|---|---|---|
|P1|SMS。配置按约定接受发送的本地短信网关，普通手机号请求发送验证码|实际 HTTP 502，验证码记录回滚为 0；期待 HTTP 200 并交付。相同 Workerd 中单独验证创建 Request，redirect=error 在调用提供方前抛 TypeError，manual 可向同一服务取得 200。影响验证码登录、注册及密码找回；密码登录已单独通过。|server/src/handlers/auth.ts:54|
|P1|H04。某账号两个设备曾同步 100 分。A 买 20 分道具，B 恢复网络后提交之前保存的 100 分脏档|A 完成扣款后 80；B 同步后 100，流水仍有 20 分支出，商品数量仍增加。期待同步后余额80。|server/src/handlers/user.ts:106；app/data/src/main/java/com/example/sheeps/data/repository/SyncRepository.kt:55|
|P1|M02。甲等待匹配，乙丙同时进入，随后各自查询状态|12轮中3轮三人都匹配，乙丙的对手都是甲，但进入不同房间。期待一对对手与房号相互对应，第三人继续等待。|server/src/handlers/match.ts:47|
|P1|Skin。通过运营账号保存一款皮肤的第一张卡面，然后获取完整商城列表|HTTP 200，后台导出 [URL,null,…]；项目实际 Android 序列化器解码整个列表失败，精确到 $[8].tiles[1]；发布前同一解码器读出15件。期待其他商品继续显示，缺图保留客户端回退。部分卡面可通过正常后台页面保存。|server/src/handlers/shop.ts:55；app/data/src/main/java/com/example/sheeps/data/model/GameModels.kt:91|
|P2|A05。游客完成第1关，随后使用本设备游客 ID 验证码登录|登录前总榜有1人；登录后第2关仍解锁，但最高通关变成0、总榜人数也变为0。期待转移成绩，保留真实通关记录。以新查询读取结果，排除了榜单原有键的短期缓存。|server/src/handlers/auth.ts:168|
|P2|H05。同一账号两台设备在购买前打开同一尚未解锁的永久皮肤，各确认购买一次|初始400分，两次后余额0，产生2笔各200分的扣款及2份相同皮肤。期待仅一份有效权益并只付一次200分。普通道具多买属于正常行为。|server/src/handlers/shop.ts:116；app/feature_menu/src/main/java/com/example/sheeps/menu/ui/components/ShopItemCard.kt:78|
|P2|S02。昨天恰为连续签到第7天，今天再签|第8天基础奖励100 + 签到任务10，总110。README明确七天循环，第8天应为基础20+10，总30。|server/src/handlers/game.ts:305；README.md:370|
|P2|T03。将三胜任务配置为0分，完成3场并领取|任务列表0，到账10，流水10；应按配置0结算。|server/src/handlers/task.ts:132|
|P3|S03。四日连签后漏签昨天，今日登录、取资料|两种响应都还显示4；期待当前连签0。今天实际签到后才正确显示1，实发30。|server/src/handlers/user.ts:152；server/src/handlers/auth.ts:306|
|P3|R06。过去一天榜单里，一人70分，一人正常退出一局得0分|零分用户在自己收到的昨日TOP3里居第二，同时 yesterdayRank=0，客户端解释为“未上榜”。列表和本人名次应一致，可以统一收录或排除零分者。|server/src/handlers/game.ts:452、473；app/feature_menu/src/main/java/com/example/sheeps/menu/ui/dialogs/DailyLeaderboardPopupDialog.kt:109|

## 已通过与覆盖边界

注册初始道具、密码登录/刷新、首次设密、改名、重置密码、首次和重复签到、断签后实际发奖、确定性布局、重复开局和成绩回执、解锁不足与重复解锁、未完成任务与重复领取、普通商城回执、购买最后一个库存的两名玩家、皮肤首次购入、消耗重发、闯关日周总榜的胜负和去重、无尽开关与失败局、普通昨日名次、双人顺序匹配及离开、版本草稿过滤/失效包回退/已有版本、公告列表。原57项另含余额竞态、注销、运营及 WebSocket 断连重连胜负。业务矩阵详见 matrix.json。榜单 KV 在设计中有短缓存，未计缺陷。昨日积分总榜是否应分模式缺少统一需求，未计缺陷。

使用新建 D1 库、初始 schema、KV 与 R2。本地验证码夹具让注册、重置、游客迁移单独运行，不代表真实短信发送通过。历史签到、测试余额和0分任务使用隔离 D1 夹具；榜单时间使用正常离线补传时间。更新 APK 的 HEAD 回应用本地桩提供；不涉及真实下载、安装、运营商送达、真实网络时延、真实设备双开的端到端验证或线上云间同步。Android 商城验证使用项目实际编译的 ShopItem 模型、当前序列化版本和两份真实本地 HTTP 响应，在 JVM 验证；没有据此推断整个 Android 进程崩溃。

## 证据

- npm-test.log，已有测试完整输出。
- matrix.json 与 run.log，34项主矩阵和每轮代表性房号。
- check.cjs，完整主矩阵脚本；连接仅限本地临时运行时。
- sms-runtime.cjs 与 sms-runtime.log，Worker HTTP 原响应与同运行时的 Request 构造对照。
- skin.cjs、SkinDecode.java、decode.sh 与 skin.log，本地运营保存和 Android 解码对照。shop-before.json、shop-after.json 为实际商城接口响应。
