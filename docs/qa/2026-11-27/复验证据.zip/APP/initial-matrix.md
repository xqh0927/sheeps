# Android 玩家端真机功能回归

提交 25c4b52c45de92fac0c119a0ba0cd6713e0dcf0b。PHK110，Android 16，1240×2772，系统简体中文。JVM 与 data、feature_game 设备测试使用原始源码。交互测试使用从该提交导出的 Debug 1.0.10（11）独立包，应用 ID 为 com.example.sheeps.qanov27，后端为同提交的本地 Worker、D1、KV。新测试账号初始余额 125、解锁第 1 关。后续专项测试调整了本地价格、模式开关和余额，另置三条时间分组的榜单样本与一名同昵称测试用户。

## 发现

| 优先级 | 场景与预期 | 实测结果及证据 |
|---|---|---|
| P1 | 服务端拒绝金币解锁时，客户端应保留原余额与锁定状态，后续同步也应一致。本地把第 3 关实际价设为 1000，普通玩家实际余额 105。 | 当前最高 2，客户端显示价 100。正常点解锁一次，实际 API 返回 400，初时 D1 仍是 105、仅关 1 和 2。界面立即开放第 3 关备战并显示余额 5，Room 中余额 5 及第 3 关均为待同步。重启并同步后云端仍有 105 币，已解锁 1、2、3，金币流水没有该关扣费。screens/reject-{preview,result,home}.xml、room、reject-client.txt、reject-server-and-same-name.txt、after-reopen-server.txt、after-reopen-ledger.txt、local-worker.log。 |
| P1 联动报价 | 玩家看到的价格应与服务端按同一进度、配置计算的应付金额一致。 | 默认配置下最高 1、余额 125，分两次分别打开第 2、3 关，页面显示 50、150。默认库的第 3 关配置价 100；隔离包仅打开后关闭，此小组未从该初始状态执行扣款。上项动态价格测试在真机实际提交并收到拒绝。跨关累计报价和单关扣价须结合 API 报告判断口径。screens/{home,locked2,locked3,reject-preview}.xml。 |
| P2 | 只有本账号的成绩应显示「我」。 | 第 2 关仅有另一用户的 150 分，两个不同用户同名 QA Nov27。登录者从通关后的第 2 关榜入口打开一次，唯一条目被标为「我」。D1 查得条目属于 other-qa-same-name，当前登录账号为 qa-nov27。screens/same-name.xml、reject-server-and-same-name.txt。 |
| P2 | 玩法说明称首次通关主线会奖励金币。 | 从初次第 1 关开局、冷重启续局到完成，一次四组三消，结算记录 784 分、83.25 秒，D1 保存 is_win=1；前后钱包均为 105，无首通金币流水。中文及英文真机说明均承诺首通给金币。需产品确认修改奖励还是文案。screens/{guide-zh,guide-en,after-back,stage-win,won-home}.xml，stage-and-shop-ledger.txt。 |

## 功能矩阵

| 检查 | 次数与操作 | 预期和结果 |
|---|---|---|
| JVM 全测 | 1 次强制重跑全部模块 testDebugUnitTest | 363 个任务执行，59/59，0 失败、错误、跳过。core 3、designsystem 1、feature_game 47、feature_menu 8。其余模块本任务无用例。gradle.log、jvm-summary.txt。 |
| data 真机 | 5 个全部测试类，6 个方法 | 6/6。覆盖本地进度替换回滚、迁移后道具幂等、重开数据库续局不重复扣费、访客并发、存档替换事务及已发布棋盘离线交接。data-explicit-device.log。 |
| feature_game 真机 | 2 个全部测试类，2 个方法 | 2/2。验证教学关 4 组三消、底层解锁与通关，以及棋盘纹理多次绘制时共享加载及 URL 更新。feature_game-explicit-device.log。两个模块最初不带类名的扫描均未进入正常输出，随后停止并枚举仓内全部 7 类重跑。 |
| 首启、登录 | 1 次隐私同意、系统通知拒绝、游客进入个人页、密码登录隔离账户、昨日未上榜弹窗关闭 | 欢迎页、0 币游客和登录后 125 币账号正确呈现。首次冷重启再次出现通知权限询问，再次拒绝后进入大厅。 |
| 闯关与续局 | 第 1 关备战携带 1 个撤销，点 1 张，返回→强停→冷启→继续，使用撤销，手动四组三消通关一次 | 余牌/槽位 12/0→11/1；冷启仍为 11/1；撤销回 12/0，携带数量 1→0；依次四组三消结算 784 分，按期解锁 2，实际首通金币见 P2。screens/{prepare,board,after-one,reopened2,resume,undo,triple,triple2,triple3,stage-win,won-home}.xml。 |
| 道具、皮肤、历史、背包 | 道具加减数量各 1 次，实际买 1 个撤销，分别查两个历史面板和背包。皮肤不足与足额各 1 次，购买后使用 1 次 | 道具单价 20，2 件总计 40，回到 1 件成功后钱包 125→105，背包由 0 到 1、两页流水均为 −20。河南皮肤售价 200，在 105 币时提示不足、确认按钮禁用；补入测试资金并签到后，530→330，皮肤库存 1、应用状态「使用中」。screens/{redeem,redeem2,purchased,bag,history-points,history-exchange,skin-insufficient,skin-applied}.xml。 |
| 每日签到与任务 | 一次签到、再点已签到入口 | 测试余额 500→530，签到 20、完成签到任务 10，两条流水各一次；天数 0→1，「每日晨曦」1/1 已领取，重复点击保持 530。另两项通关任务显示 1/3、1/5。screens/{sign,sign-repeat}.xml，stage-and-shop-ledger.txt。 |
| 关卡榜与规则 | 第 1 关从结算页进榜，点今日/本周/历史各一次，并查规则；另从大厅点第 2 关榜 | 第 1 关历史 4 人，周榜 3 人，日榜 2 人。包含本轮 784 分及设置在当日、本周、历史的 101/222/333 样本，过滤和得分排序正确。规则弹窗可关闭，同名标记另列 P2。screens/rank-*.xml、rules.xml、same-name.xml。 |
| 匹配和对决 | 排队后点退出一次，再匹配。最终双端均连接本地 Worker，手机实际点牌、退出弹窗取消一次，再确认一次 | 真机与协议测试对端各有 101，触牌后槽 0/7→1/7；取消仍连接，确认后回大厅，测试对端收到 OPPONENT_QUIT。首次连接环境差异见下。screens/{duel-enter,duel-wait,local-duel,duel-one,duel-cancel,duel-quit}.xml，peer.log。 |
| 无尽 | 先确认关闭开关时模式入口不显示，打开本地模式开关后进入空总榜、说明、开局。冻结、暂停、暂停触牌、恢复触牌和返回各 1 次 | 空榜提示明确；初始波次 1/0 分、冻结 ×3，使用后冻结计时，暂停期间点击槽仍 0/7，恢复后槽 1/7、冻结 ×2，返回大厅。screens/{endless-rank,endless-intro,endless-start,frozen,paused,paused-hold,endless-take,endless-back}.xml。 |
| 设置、本地化 | 两项音频开关各切一次、主题从跟随系统切森林绿、简中→英语→简中各一次、两语言打开玩法说明 | 两开关从选中变未选中，重新进设置依然关闭；主题显示 Forest，界面语言随选择切换。未采集设备实际声音。screens/{settings,settings-off,theme-changed,language-en,english-settings,guide-en,guide-zh}.xml。 |

## 范围与清理

本轮限一部手机、一个 Android 系统和 Debug 隔离构建。未验证签名 Release 原包同机升级、全部关卡、七槽失败/复活、其他道具实机效果、全部皮肤外观、多机真玩家完整对决、对战技能/断线重连、无尽死亡结算、全部语言翻译与主题、推送送达、真实短信、注册找回、注销、隐私链接和长期稳定性。对局对端是协议测试端；UI 测试真实完成的是一关首通。

本轮最初的隔离包仅重定向 REST，第一次用本地生成的随机对局匹配时默认在线 WebSocket 曾成功握手，进入退出确认对话框后直接强停，当时没有手动点牌、发送玩法指令、确认认输或生产结算。发现独立 WS 配置后也改到本地，再重新配对完成交互和退赛测试。本地 QA 收尾已卸载 QA 专用包、移除 USB 反向端口和设备临时 UI 文件、结束本地 Worker。设备保留测试前已有的主 App 及两个模块测试包，主 App 未重装或清数据。两模块测试包曾以本提交构建物覆盖安装。仓库 git status 与开始时一样，仅原有未跟踪目录 docs/android-ui/。本地原始记录保存在本目录，UI 抓取含中间过渡和系统画面，文件数不代表测试用例数。
